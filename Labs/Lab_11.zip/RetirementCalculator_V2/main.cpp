/* 
 * File:   main.cpp
 * Author: Benjamin Wodhams
 * Created on July 8, 2015, 10:45 AM
 * Purpose : Retirement Calculator
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global constants

//Function Prototypes
void hding (string,string,string,string,string,string); // Heading function
void rtrmnt (unsigned int, unsigned int, float, float, float, float, float, float, float); //Retirement Function
void table (unsigned int, unsigned int, float, float, float, float, float);


//Execution begins here!

int main(int argc, char** argv) {
    //Declare Variables
    float salary=90000; //Average Salary in $'s
    float invRate=0.05f; //Investment rate of 5%
    float savReq; //Savings required at retirement
    float pDep=0.1f; //Of your gross salary -> Percentage Deposited
    float deposit; //Yearly Deposit in $'s
    float savings=0; //Initial savings at start of Employment
    float year=0; //Start at year 0
    float date=18;
    float intEarn; // Interest earned
    string yr="Year";
    string dte="Date";
    string slry="Salary";
    string svng="Savings";
    string intr="Interest";
    string depo="Deposit";
    
    
    //Calculate required savings
    savReq=salary/invRate;
    
    //Calculate Interest Earned
    intEarn=invRate*savings;


    
    //Display the results
    hding(yr,dte,slry,svng,intr,depo);
    cout<<endl<<endl;
    cout<<fixed<<showpoint<<setprecision(2);
    
    rtrmnt(year,date,salary,savings,intEarn,deposit,savReq,pDep,invRate);
    
 
    
    //Exit Stage Right!
    return 0;
}

/*******************************************************************
 ******************************  hding  ****************************
 ****  Purpose:  To display the heading                         ****
 ****  Outputs                                                  ****
 ****  yr -> Number of years                                    ****
 ****  dte    -> Date                                           ****
 ****  slry   -> Salary                                         ****
 ****  svng -> Savings                                          ****
 ****  intr - > Interest                                        ****
 ****  depo -> Deposit                                          ****
 *******************************************************************
 */


void hding (string yr,string dte,string slry, string svng, string intr,string depo){
    //Display the Heading
    cout<<yr<<"  "<<dte<<"    "<<slry<<"      "<<svng<<"       "<<intr<<"     "<<depo<<endl;
}



/*******************************************************************
 ******************************  rtrmnt  ***************************
 ****  Purpose:  Calculate retirement info                      ****
 ****  Outputs                                                  ****
 ****  year -> Number of years                                  ****
 ****  date    -> Date                                          ****
 ****  slary   -> Salary                                        ****
 ****  savings -> Savings                                       ****
 ****  intEarn - > Interest                                     ****
 ****  deposit -> Deposit                                       ****
 ****  savReq  -> Savings required                              ****    
 ****  pDep -> Percentage deposit                               ****
 ****  invRate -> Investment rate                               ****
 *******************************************************************
 */



void rtrmnt (unsigned int year, unsigned int date, float salary, float savings, float intEarn, float deposit, float savReq, float pDep, float invRate){
    
     //Calculate required savings
     //savReq=salary/invRate;
    
    //Loop to calculate when Retirement is possible
    do{
        deposit=pDep*salary; //Deposit based on salary
        table(year,date,salary,savings,intEarn,deposit,invRate);
        savings*=(1+invRate); //Earnings based upon investment rate
        savings+=deposit; //Add the deposit after earning interest  
        intEarn=invRate*savings;
        year++;
        date++;
        table(year,date,salary,savings,intEarn,deposit,invRate);
        
    }while(savings<savReq); //When we have enough to retire then exit the loop  
}






/*******************************************************************
 ******************************  table   ***************************
 ****  Purpose:  Display information in table                   ****
 ****  Outputs                                                  ****
 ****  year -> Number of years                                  ****
 ****  date    -> Date                                          ****
 ****  slary   -> Salary                                        ****
 ****  savings -> Savings                                       ****
 ****  intEarn - > Interest                                     ****
 ****  deposit -> Deposit                                       ****
 ****  savReq  -> Savings required                              ****    
 ****  pDep -> Percentage deposit                               ****
 ****  invRate -> Investment rate                               ****
 *******************************************************************
 */

void table(unsigned int year, unsigned int date, float salary, float savings, float intEarn, float deposit, float invRate){
        cout<<setw(3)<<year<<"    "<<setw(3)<<"06/01/"<<date<<"     $"<<setw(3)<<salary<<"     $"<<setw(10)<<savings<<"     $"<<setw(10)<<intEarn<<"      $"<<setw(5)<<deposit<<endl;
}


