/* 
 * File:   main.cpp
 * Author: Ben Wodhams
 *
 * Created on June 26, 2015, 3:00 PM
 * Purpose : Gaddis 6th Edition Chapter 2 Number 1
 */

//System Libraries
#include <iostream>//I/O Library
using namespace std;//Namespace for iostream
 
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins Here!
int main(int argc, char** argv) {
    
    
    //Declare variables
    int var1=62,var2=99; //Declares Variable 1 and Variable 2
    float total=var1+var2; //Total = Variable 1 + Variable 2
    
    
   //Output
    cout<<"The total is: "
            <<total<<endl;
    
    
     return 0;
            
}
