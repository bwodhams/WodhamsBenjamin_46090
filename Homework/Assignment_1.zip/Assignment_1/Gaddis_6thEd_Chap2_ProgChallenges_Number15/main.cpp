/* 
 * File:   main.cpp
 * Author: Ben Wodhams
 *
 * Created on June 26, 2015, 4:30 PM
 * Purpose : Gaddis 6th Edition Chapter 2 Number 15
 */

//System Libraries
#include <iostream>//I/O Library

using namespace std;//Namespace for iostream
 
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins Here!
int main(int argc, char** argv) {
    
    
    //Declare variables 
    
    
   //Output
    cout<<"         *"<<endl;
    cout<<"        ***"<<endl;
    cout<<"       *****"<<endl;
    cout<<"      *******"<<endl;
    
    
    
     return 0;
            
}
